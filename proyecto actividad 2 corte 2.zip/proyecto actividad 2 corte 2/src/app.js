const express = require('express');
const cors = require('cors');
const productRoutes = require('./routes/productRoutes');
const sequelize = require('./database/db');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/products', productRoutes);

sequelize.authenticate()
  .then(() => console.log('Database connected...'))
  .catch(err => console.log('Error: ' + err));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
